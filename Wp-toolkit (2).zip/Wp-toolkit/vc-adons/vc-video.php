<?php 
// VC_BLOCK_LOAD_PHP START FROM HERE 
if (!defined('ABSPATH')) { exit; }

vc_map( array(
  "name" =>esc_html__( "Stock video", "stock-toolkit" ),
  "base" => "stock_video",
  "category" =>esc_html__( "Stock", "stock-toolkit"),
  "icon" => stock_ACC_URL. '/assets/img/iconic-box-1.png',
  "params" => array(
     array(
       'type' => 'dropdown',
       'heading' =>esc_html__( 'Logo carousel Autoplay',  "stock-toolkit" ),
       'param_name' => 'autoplay',
       'value' => array(
        esc_html__( 'True',  "stock-toolkit"  ) => 'true',
        esc_html__( 'False',  "stock-toolkit"  ) => 'false',
       ),
       "description" => esc_html__( "For desable slides autoplay select true. ", "stock-toolkit" )
     ),
     array(
       "type" => "textfield",
       'heading' =>esc_html__( 'Logo carousel autoplayTimeout',  "stock-toolkit" ),
       "param_name" => "autoplayTimeout",
       "value" =>esc_html__( "5000", "stock-toolkit" ),
       "description" => esc_html__( "Type only number for select slides autoplayTimeout. ", "stock-toolkit" ),
       'dependency'   => array( 
          'element' => 'autoplay',
          'value' => array("true"), 
        ),
     ),
  )
) 
);
vc_map( array(
  "name" =>esc_html__( "Crazyland video", "stock-toolkit" ),
  "base" => "craziland_video",
  "category" =>esc_html__( "Crazyland", "stock-toolkit"),
  "icon" => stock_ACC_URL. '/assets/img/iconic-box-1.png',
  "params" => array(
     array(
       'type' => 'dropdown',
       'heading' =>esc_html__( 'Video source',  "stock-toolkit" ),
       'param_name' => 'source',
       'value' => array(
        esc_html__( 'Youtube',  "stock-toolkit"  ) => '1',
        esc_html__( 'Vimeo',  "stock-toolkit"  ) => '2',
       ),
       "description" => esc_html__( "From here you can select video source", "stock-toolkit" )
     ),
     array(
       "type" => "textfield",
       'heading' =>esc_html__( 'Video ID',  "stock-toolkit" ),
       "param_name" => "id",
     ),
     array(
       'type' => 'dropdown',
       'heading' =>esc_html__( 'Thumbnail source',  "stock-toolkit" ),
       'param_name' => 'thumb_source',
       'value' => array(
        esc_html__( 'Automatic',  "stock-toolkit"  ) => '1',
        esc_html__( 'Custom',  "stock-toolkit"  ) => '2',
       ),
       "description" => esc_html__( "From here you can select video source Type", "stock-toolkit" )
     ),
     array(
       "type" => "attach_image",
       'heading' =>esc_html__( 'Upload video thumbnail',  "stock-toolkit" ),
       "param_name" => "video_thumb",
       "description" => esc_html__( "From here you can upload video thumb", "stock-toolkit" ),
       'dependency'   => array( 
          'element' => 'autoplay',
          'value' => array("2"), 
        ),
     ),
  )
) 
);

