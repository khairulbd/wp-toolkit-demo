<?php 

// VC_BLOCK_LOAD_PHP START FROM HERE
 
 
if (!defined('ABSPATH')) { exit; }
 
 
//Class Started
 
class stockVCExtendAddonClass {
    function __construct(){
        //We safely integrate with VC with this hook
        add_action('init', array($this, 'stockIntegrateWithVC'));
    }
 
    public function stockIntegrateWithVC() {
        //Check if visual composer is not installed
 
        if( ! defined('WPB_VC_VERSION') ){
            add_action('admin_notice', array($this, 'stockShowVcVersionNotice'));
            return;
        }
 
        //Visual composer addons.
        include stock_ACC_PATH . 'vc-adons/vc-blocks.php';
        include stock_ACC_PATH . 'vc-adons/vc-slides.php';
        include stock_ACC_PATH . 'vc-adons/vc-logo-carousel.php';
        include stock_ACC_PATH . 'vc-adons/vc-service.php';
        include stock_ACC_PATH . 'vc-adons/vc-cta.php';
        include stock_ACC_PATH . 'vc-adons/vc-tile-gallery.php';
        include stock_ACC_PATH . 'vc-adons/vc-video.php';
    }
 
    //show visual composer version
    public function stockShowVcVersionNotice(){
        $theme_data = wp_get_theme();
        echo '
        <div class="notice notice-warning">
        <p>'.sprintf(__('<strong>%S</strong> recommends <strong><a href="'.site_url().'/wp-admin/themes.php?page=tgmpa-install-plugins" target="_blank">visual composer </a></strong> plugin to be installed and activated on your site.', 'stock-crazycafe'), $theme_data->get('name')).'</P>
        </div>';
    }
}
 
//finally initialize code
 
new stockVCExtendAddonClass();