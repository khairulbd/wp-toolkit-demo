<?php 
// VC_BLOCK_LOAD_PHP START FROM HERE 
if (!defined('ABSPATH')) { exit; }

function stock_toolkit_get_slide_as_list(){
  $args = wp_parse_args( array(
      'post_type' => 'slide',
      'numberposts' => -1,
    ) );
  $posts = get_posts( $args );

  $post_options = array(esc_html__( '-- Select slide --', 'stock-toolkit' )=>'');
  if($posts){
    foreach ($posts as $post) {
      $post_options[ $post->post_title ] = $post->ID;
    }
  }
  return $post_options;
}

 vc_map( array(
    "name" =>esc_html__( "stock slides", "stock-toolkit" ),
    "base" => "stock_slides",
    "category" =>esc_html__( "Stock", "stock-toolkit"),
    'icon' => stock_ACC_URL. '/assets/img/iconic-box-1.png',
    "params" => array(
      array(
         "type" => "textfield",
         "heading" =>esc_html__( "Slide count",  "stock-toolkit" ),
         "param_name" => "count",
         "value" =>esc_html__( "3", "stock-toolkit" ),
         "description" => esc_html__( "Type only number for select slides count. ", "stock-toolkit" )
       ),
      array(
         'type' => 'textfield',
         'heading' =>esc_html__( "Slide height",  "stock-toolkit" ),
         'param_name' => 'height',
         "value" =>esc_html__( "608", "stock-toolkit" ),
         "description" => esc_html__( "Type only number for select slides area height. ", "stock-toolkit" )
       ),
       array(
         'type' => 'dropdown',
         'heading' =>esc_html__( 'Select slide',  "stock-toolkit" ),
         "param_name" => "slider_id",
         "value" => stock_toolkit_get_slide_as_list(),
         "description" => esc_html__( "", "stock-toolkit" ),
         "dependency"   => array( 
            "element" => "count",
            "value" => array("1"), 
        ),
       ),
       array(
         'type' => 'dropdown',
         'heading' =>esc_html__( 'Slide Loop', "stock-toolkit" ),
         'param_name' => 'loop',
         "std" => esc_html__( "true",  "stock-toolkit" ),
         'value' => array(
          esc_html__( 'True',  "stock-toolkit"  ) => 'true',
          esc_html__( 'False',  "stock-toolkit"  ) => 'false',
         ),
         'dependency'   => array( 
          'element' => 'count',
          'value' => array('2', '3', '4', '5', '6', '7', '8', '9', '10'), 
        ),
         "description" => esc_html__( "For desable slides loop select true. ", "stock-toolkit" )
       ),
       array(
         'type' => 'dropdown',
         'heading' =>esc_html__( 'Slide Dots',  "stock-toolkit" ),
         'param_name' => 'dots',
         "std" => esc_html__( "true",  "stock-toolkit" ),
         'value' => array(
          esc_html__( 'True',  "stock-toolkit"  ) => 'true',
          esc_html__( 'False',  "stock-toolkit"  ) => 'false',
         ),
         'dependency'   => array( 
          'element' => 'count',
          'value' => array('2', '3', '4', '5', '6', '7', '8', '9', '10'), 
        ),
         "description" => esc_html__( "For desable slides dots select true. ", "stock-toolkit" )
       ),
       array(
         'type' => 'dropdown',
         'heading' =>esc_html__( 'Slide Nav',  "stock-toolkit" ),
         'param_name' => 'nav',
         "std" => esc_html__( "true",  "stock-toolkit" ),
         'value' => array(
          esc_html__( 'True',  "stock-toolkit"  ) => 'true',
          esc_html__( 'False',  "stock-toolkit"  ) => 'false',
         ),
         'dependency'   => array( 
          'element' => 'count',
          'value' => array('2', '3', '4', '5', '6', '7', '8', '9', '10'), 
        ),
         "description" => esc_html__( "For desable slides nav select true. ", "stock-toolkit" )
       ),
       array(
         'type' => 'dropdown',
         'heading' =>esc_html__( 'Slide Autoplay',  "stock-toolkit" ),
         'param_name' => 'autoplay',
         "std" => esc_html__( "true",  "stock-toolkit" ),
         'value' => array(
          esc_html__( 'True',  "stock-toolkit"  ) => 'true',
          esc_html__( 'False',  "stock-toolkit"  ) => 'false',
         ),
         'dependency'   => array( 
          'element' => 'count',
          'value' => array('2', '3', '4', '5', '6', '7', '8', '9', '10'), 
        ),
         "description" => esc_html__( "For desable slides autoplay select true. ", "stock-toolkit" )
       ),
       array(
         'type' => 'textfield',
         'heading' =>esc_html__( 'Slide autoplayTimeout',  "stock-toolkit" ),
         'param_name' => 'autoplayTimeout',
         "value" =>esc_html__( "5000", "stock-toolkit" ),
         "description" => esc_html__( "Type only number for select slides autoplayTimeout. ", "stock-toolkit" ),
         'dependency'   => array( 
          'element' => 'count',
          'value' => array('2', '3', '4', '5', '6', '7', '8', '9', '10'), 
        ),
       ),
    )
 ) 
);

