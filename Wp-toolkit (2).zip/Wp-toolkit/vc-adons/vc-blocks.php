<?php 
// VC_BLOCK_LOAD_PHP START FROM HERE 
if (!defined('ABSPATH')) { exit; }



function stock_toolkit_get_page_as_list(){
  $args = wp_parse_args( array(
    'post_type' => 'page',
    'numberposts' => -1,
  ) );
  $posts = get_posts( $args );

  $post_options = array(esc_html__( '-- Select page --', 'stock-toolkit' )=>'');
  if($posts){
    foreach ($posts as $post) {
      $post_options[ $post->post_title ] = $post->ID;
    }
  }
  return $post_options;
}

function stock_toolkit_get_cagegories_list(){
  $product_categories = get_terms( array(
    'taxonomy' => 'product_cat',
    'hide_empty' => false,
  ) );

  $product_category_options = array(esc_html__( '-- Select Categories --', 'light-toolkit' ) => '');
  if($product_categories){
    foreach ($product_categories as $product_category) {
      $product_category_options[ $product_category->name ] = $product_category->term_id;
    }
  }
  return $product_category_options;
}

// stock category thumbnail
   vc_map( array(
      "name" =>esc_html__( "stock product category thumbnail", "stock-toolkit" ),
      "base" => "ws_pct",
      "category" =>esc_html__( "Stock", "stock-toolkit"),
      'icon' => stock_ACC_URL. '/assets/img/iconic-box.png',
      "params" => array(
         array(
            "type" => "checkbox",
            "heading" =>esc_html__( "Categories", "stock-toolkit" ),
            "param_name" => "cat_ids",
            "value" => stock_toolkit_get_cagegories_list(),
         ),
        array(
            "type" => "dropdown",
            "heading" =>esc_html__( "Columns", "stock-toolkit" ),
            "param_name" => "columns",
            "std" => 4,
            "value" => array(
                esc_html( 'One Column', 'inventor-toolkit' ) => 1,
                esc_html( 'Two Columns', 'inventor-toolkit' ) => 2,
                esc_html( 'Three Columns', 'inventor-toolkit' ) => 3,
                esc_html( 'Four Columns', 'inventor-toolkit' ) => 4,
            ),
         ),
      )
   ) 
 );

// stock section title
   vc_map( array(
      "name" =>esc_html__( "Stock section title", "stock-toolkit" ),
      "base" => "stock_section_title",
      "category" =>esc_html__( "Stock", "stock-toolkit"),
      'icon' => stock_ACC_URL. '/assets/img/iconic-box.png',
      "params" => array(
        array(
            "type" => "textfield",
            "heading" =>esc_html__( "Button Text", "stock-toolkit" ),
            "param_name" => "section_title",
            "std" =>esc_html__( "Shop Now", "stock-toolkit" ),
            "description" => esc_html__( "Type section title text here", "stock-toolkit" ),
         ),
         array(
            "type" => "textarea_html",
            "heading" =>esc_html__( "Content", "stock-toolkit" ),
            "param_name" => "content",
            "value" =>esc_html__( "fa fa-phone", "stock-toolkit" ),
            "description" => esc_html__( "Type section content text.", "stock-toolkit" )
         ),
      )
   ) 
 );

// stock product carousel
   vc_map( array(
      "name" =>esc_html__( "Stock Product", "stock-toolkit" ),
      "base" => "stock_product_carousel",
      "category" =>esc_html__( "Stock", "stock-toolkit"),
      'icon' => stock_ACC_URL. '/assets/img/iconic-box.png',
      "params" => array(
         array(
            "type" => "textarea_html",
            "heading" =>esc_html__( "Content", "stock-toolkit" ),
            "param_name" => "content",
            "value" =>esc_html__( "fa fa-phone", "stock-toolkit" ),
            "description" => esc_html__( "Select Icon.", "stock-toolkit" )
         ),
      )
   ) 
 );

// stock test
   vc_map( array(
      "name" =>esc_html__( "stock Iconic Box", "stock-toolkit" ),
      "base" => "bartag",
      "class" => "",
      "category" =>esc_html__( "Stock", "stock-toolkit"),
      'icon' => stock_ACC_URL. '/assets/img/iconic-box.png',
      "params" => array(
         array(
            "type" => "iconpicker",
            "heading" =>esc_html__( "Select Icon", "stock-toolkit" ),
            "param_name" => "icon",
            "value" =>esc_html__( "fa fa-phone", "stock-toolkit" ),
            "description" => esc_html__( "Select Icon.", "stock-toolkit" )
         ),
         array(
            "type" => "textarea_html",
            "heading" =>esc_html__( "Content", "stock-toolkit" ),
            "param_name" => "content",
            "value" =>esc_html__( "fa fa-phone", "stock-toolkit" ),
            "description" => esc_html__( "Select Icon.", "stock-toolkit" )
         ),
      )
   ) 
 );


   // stock promo addon
   vc_map( array(
      "name" =>esc_html__( "stock Promo", "stock-toolkit" ),
      "base" => "ws_promo",
      "category" =>esc_html__( "Stock", "stock-toolkit"),
      'icon' => stock_ACC_URL. '/assets/img/iconic-box.png',
      "params" => array(
         array(
            "type" => "attach_image",
            "heading" =>esc_html__( "Image", "stock-toolkit" ),
            "param_name" => "img",
            "description" => esc_html__( "Upload Image.", "stock-toolkit" )
         ),
         array(
            "type" => "textarea_html",
            "heading" =>esc_html__( "Content", "stock-toolkit" ),
            "param_name" => "content",
            "value" =>esc_html__( "fa fa-phone", "stock-toolkit" ),
            "description" => esc_html__( "Select Icon.", "stock-toolkit" )
         ),
         array(
            "type" => "textfield",
            "heading" =>esc_html__( "Button Text", "stock-toolkit" ),
            "param_name" => "btn_text",
            "std" =>esc_html__( "Shop Now", "stock-toolkit" ),
            "description" => esc_html__( "Type button text here", "stock-toolkit" ),
         ),
         array(
            "type" => "textfield",
            "heading" =>esc_html__( "Background Color", "stock-toolkit" ),
            "param_name" => "bg_color",
            "std" =>esc_html__( "#fff", "stock-toolkit" ),
            "description" => esc_html__( "Type background Color code here", "stock-toolkit" ),
         ),
         array(
            "type" => "dropdown",
            "heading" =>esc_html__( "Enable Icon", "stock-toolkit" ),
            "param_name" => "icon",
            "std" => 1,
            "description" => esc_html__( "Enable button icon here", "stock-toolkit" ),
            "value" => array(
                esc_html( 'Yes', 'stock-toolkit' ) => 1,
                esc_html( 'No', 'stock-toolkit' ) => 2,
            ),
         ),
         array(
            "type" => "iconpicker",
            "heading" =>esc_html__( "Select Icon", "stock-toolkit" ),
            "param_name" => "icon_text",
            "std" =>esc_html__( "fa fa-long-arrow-right", "stock-toolkit" ),
            "description" => esc_html__( "Sclect button icon here", "stock-toolkit" ),
         ),
         array(
            "type" => "dropdown",
            "heading" =>esc_html__( "Select Page", "stock-toolkit" ),
            "param_name" => "link",
            "value" => stock_toolkit_get_page_as_list(),
         ),
      )
   ) 
);

   // stock post addon
   vc_map( array(
      "name" =>esc_html__( "stock post", "stock-toolkit" ),
      "base" => "stock_toolkit_post",
      "category" =>esc_html__( "Stock", "stock-toolkit"),
      'icon' => stock_ACC_URL. '/assets/img/iconic-box.png',
      "params" => array(
         array(
            "type" => "textfield",
            "heading" =>esc_html__( "Post count", "stock-toolkit" ),
            "param_name" => "count",
            "value" => esc_html__( "2", "stock-toolkit" ),
            "description" => esc_html__( "Type count number here.", "stock-toolkit" )
         ),
         array(
            "type" => "dropdown",
            "heading" =>esc_html__( "Show date", "stock-toolkit" ),
            "param_name" => "show_date",
            "std" => 3,
            "description" => esc_html__( "Show date", "stock-toolkit" ),
            "value" => array(
                esc_html__( 'Yes', 'stock-toolkit' ) => true,
                esc_html__( 'No', 'stock-toolkit' ) => false,
            ),
         ),
         array(
            "type" => "dropdown",
            "heading" => esc_html__( "Show comments", "stock-toolkit" ),
            "param_name" => "show_comments",
            "std" => 3,
            "description" => esc_html__( "Show comments", "stock-toolkit" ),
            "value" => array(
                esc_html__( 'Yes', 'stock-toolkit' ) => true,
                esc_html__( 'No', 'stock-toolkit' ) => false,
            ),
         ),
         array(
            "type" => "dropdown",
            "heading" =>esc_html__( "Type number of column", "stock-toolkit" ),
            "param_name" => "columns",
            "std" => 3,
            "description" => esc_html__( "Enable button icon here", "stock-toolkit" ),
            "value" => array(
                esc_html__( 'col', 'stock-toolkit' ) => 1,
                esc_html__( 'col-lg-6', 'stock-toolkit' ) => 2,
                esc_html__( 'col-lg-3', 'stock-toolkit' ) => 3,
                esc_html__( 'col-lg-4', 'stock-toolkit' ) => 4,
            ),
         ),
      )
   ) 
);