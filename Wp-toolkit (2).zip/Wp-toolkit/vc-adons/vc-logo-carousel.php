<?php 
// VC_BLOCK_LOAD_PHP START FROM HERE 
if (!defined('ABSPATH')) { exit; }

vc_map( array(
  "name" =>esc_html__( "Stock logo carousel", "stock-toolkit" ),
  "base" => "stock_logo_carousel",
  "category" =>esc_html__( "Stock", "stock-toolkit"),
  "icon" => stock_ACC_URL. '/assets/img/iconic-box-1.png',
  "params" => array(
    array(
       "type" => "attach_images",
       "heading" =>esc_html__( "Upload logos",  "stock-toolkit" ),
       "param_name" => "logos",
       "description" => esc_html__( "Upload logos for carousel. ", "stock-toolkit" )
     ),
     array(
       'type' => 'textfield',
       'heading' =>esc_html__( 'Dextop count',  "stock-toolkit" ),
       'param_name' => 'dextop_count',
       "std" => esc_html__( "5",  "stock-toolkit" ),
       "description" => esc_html__( "Type number for dextop image", "stock-toolkit" )
     ),
     array(
       'type' => 'textfield',
       'heading' =>esc_html__( 'Tablet count',  "stock-toolkit" ),
       'param_name' => 'tablet_count',
       "std" => esc_html__( "3",  "stock-toolkit" ),
       "description" => esc_html__( "Type number for dextop image", "stock-toolkit" )
     ),
     array(
       'type' => 'textfield',
       'heading' =>esc_html__( 'Mobile count',  "stock-toolkit" ),
       'param_name' => 'mobile_count',
       "std" => esc_html__( "2",  "stock-toolkit" ),
       "description" => esc_html__( "Type number for dextop image", "stock-toolkit" )
     ),
     array(
       'type' => 'dropdown',
       'heading' =>esc_html__( 'Logo slide Loop',  "stock-toolkit" ),
       'param_name' => 'loop',
       "std" => esc_html__( "true",  "stock-toolkit" ),
       "value" => array(
        esc_html__( 'True',  "stock-toolkit"  ) => 'true',
        esc_html__( 'False',  "stock-toolkit"  ) => 'false',
       ),
       "description" => esc_html__( "For desable slides loop select true. ", "stock-toolkit" )
     ),
     array(
       "type" => "dropdown",
       "heading" => esc_html__( "Logo carousel Dots",  "stock-toolkit" ),
       'param_name' => 'dots',
       "std" => esc_html__( "true",  "stock-toolkit" ),
       "value" => array(
        esc_html__( "True",  "stock-toolkit"  ) => 'true',
        esc_html__( "False",  "stock-toolkit"  ) => 'false',
       ),
       "description" => esc_html__( "For desable slides dots select true. ", "stock-toolkit" )
     ),
     array(
       'type' => 'dropdown',
       'heading' =>esc_html__( 'Logo carousel Nav',  "stock-toolkit" ),
       'param_name' => 'nav',
       "std" => esc_html__( "true",  "stock-toolkit" ),
       'value' => array(
        esc_html__( 'True',  "stock-toolkit"  ) => 'true',
        esc_html__( 'False',  "stock-toolkit"  ) => 'false',
       ),
       "description" => esc_html__( "For desable slides nav select true. ", "stock-toolkit" )
     ),
     array(
       'type' => 'dropdown',
       'heading' =>esc_html__( 'Logo carousel Autoplay',  "stock-toolkit" ),
       'param_name' => 'autoplay',
       'value' => array(
        esc_html__( 'True',  "stock-toolkit"  ) => 'true',
        esc_html__( 'False',  "stock-toolkit"  ) => 'false',
       ),
       "description" => esc_html__( "For desable slides autoplay select true. ", "stock-toolkit" )
     ),
     array(
       "type" => "textfield",
       'heading' =>esc_html__( 'Logo carousel autoplayTimeout',  "stock-toolkit" ),
       "param_name" => "autoplayTimeout",
       "value" =>esc_html__( "5000", "stock-toolkit" ),
       "description" => esc_html__( "Type only number for select slides autoplayTimeout. ", "stock-toolkit" ),
       'dependency'   => array( 
          'element' => 'autoplay',
          'value' => array("true"), 
        ),
     ),
  )
) 
);

