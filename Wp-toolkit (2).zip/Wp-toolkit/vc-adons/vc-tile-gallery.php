<?php 
// VC_BLOCK_LOAD_PHP START FROM HERE 
if (!defined('ABSPATH')) { exit; }

vc_map( array(
  "name" =>esc_html__( "Stock tile gallery", "stock-toolkit" ),
  "base" => "stock_tile_gallery",
  "category" =>esc_html__( "Stock", "stock-toolkit"),
  "icon" => stock_ACC_URL. '/assets/img/iconic-box-1.png',
  "params" => array(
    array(
       "type" => "attach_images",
       "heading" =>esc_html__( "Upload gallery image",  "stock-toolkit" ),
       "param_name" => "images",
       "description" => esc_html__( "Upload gallery image. ", "stock-toolkit" )
     ),
     array(
       'type' => 'textfield',
       'heading' =>esc_html__( 'Dextop count',  "stock-toolkit" ),
       'param_name' => 'height',
       "std" => esc_html__( "310",  "stock-toolkit" ),
       "description" => esc_html__( "Type image height in number", "stock-toolkit" )
     )
  )
) 
);

