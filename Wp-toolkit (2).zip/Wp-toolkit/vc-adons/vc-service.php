<?php 
// VC_BLOCK_LOAD_PHP START FROM HERE 
if (!defined('ABSPATH')) { exit; }

function stock_toolkit_service_page_as_list(){
  $args = wp_parse_args( array(
      'post_type' => 'page',
      'numberposts' => -1,
    ) );
  $posts = get_posts( $args );

  $post_options = array(esc_html__( '-- Select page --', 'stock-toolkit' )=>'');
  if($posts){
    foreach ($posts as $post) {
      $post_options[ $post->post_title ] = $post->ID;
    }
  }
  return $post_options;
}


vc_map( array(
  "name" =>esc_html__( "Stock service box", "stock-toolkit" ),
  "base" => "stock_service_box",
  "category" =>esc_html__( "Stock", "stock-toolkit"),
  "icon" => stock_ACC_URL. '/assets/img/iconic-box-1.png',
  "params" => array(
    array(
       "type" => "textfield",
       "heading" =>esc_html__( "Type title",  "stock-toolkit" ),
       "param_name" => "title",
       "description" => esc_html__( "Type title. ", "stock-toolkit" )
     ),
     array(
       'type' => 'textarea',
       'heading' =>esc_html__( 'Type content',  "stock-toolkit" ),
       'param_name' => 'desc',
       "description" => esc_html__( "Type content", "stock-toolkit" )
     ),
     array(
       'type' => 'dropdown',
       'heading' =>esc_html__( 'Link type',  "stock-toolkit" ),
       'param_name' => 'type',
       "std" => esc_html__( "1",  "stock-toolkit" ),
       "value" => array(
        esc_html__( 'Link to page',  "stock-toolkit"  ) => 1,
        esc_html__( 'External link',  "stock-toolkit"  ) => 2,
       ),
       "description" => esc_html__( "Select link type. ", "stock-toolkit" )
     ),
     array(
       'type' => 'dropdown',
       'heading' =>esc_html__( 'Link to page',  "stock-toolkit" ),
       'param_name' => 'link_to_page',
       "value" => stock_toolkit_service_page_as_list(),
       "description" => esc_html__( "Select any page for link", "stock-toolkit" ),
       'dependency'   => array( 
          'element' => 'type',
          'value' => array("1"), 
        ),
     ),
     array(
       'type' => 'textfield',
       'heading' => esc_html__( 'Link to external page',  "stock-toolkit" ),
       'param_name' => 'external_link',
       "description" => esc_html__( "Type any page for link", "stock-toolkit" ),
       'dependency'   => array( 
          'element' => 'type',
          'value' => array("2"), 
        ),
     ),
     array(
       "type" => "textfield",
       'heading' => esc_html__( 'Link text',  "stock-toolkit" ),
       "param_name" => "link_text",
       "std" => esc_html__( "See more", "stock-toolkit" ),
       "description" => esc_html__( "Type link text here. ", "stock-toolkit" ),
     ),
     array(
         'type' => 'dropdown',
         'heading' => esc_html__( 'Icon type',  "stock-toolkit" ),
         'param_name' => 'icon_type',
         "std" => esc_html__( "1",  "stock-toolkit" ),
         'value' => array(
          esc_html__( 'Upload Icon',  "stock-toolkit"  ) => 1,
          esc_html__( 'FontAwesome',  "stock-toolkit"  ) => 2,
         ),
         "description" => esc_html__( "Select icon type for uploading icon", "stock-toolkit" )
       ),
     array(
       'type' => 'attach_image',
       'heading' =>esc_html__( 'Upload Icon',  "stock-toolkit" ),
       'param_name' => 'upload_icon',
       "description" => esc_html__( "Upload Icon from here.", "stock-toolkit" ),
       'dependency'   => array( 
          'element' => 'icon_type',
          'value' => array("1"), 
        ),
     ),
     array(
       'type' => 'iconpicker',
       'heading' =>esc_html__( 'Choose Icon',  "stock-toolkit" ),
       'param_name' => 'choose_icon',
       "description" => esc_html__( "Choose Icon from here.", "stock-toolkit" ),
       'dependency'   => array( 
          'element' => 'icon_type',
          'value' => array("2"), 
        ),
     ),
     array(
       'type' => 'attach_image',
       'heading' =>esc_html__( 'Box background',  "stock-toolkit" ),
       'param_name' => 'box_background',
       "description" => esc_html__( "Upload background image from here.", "stock-toolkit" ),
     ),
  )
) 
);

