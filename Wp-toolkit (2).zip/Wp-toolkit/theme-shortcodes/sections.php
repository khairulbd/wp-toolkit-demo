<?php 

//Exit if accesed directly

if (!defined('ABSPATH')) { exit; }

add_action( 'init', 'stock_custom_post' );
function stock_custom_post() {
    register_post_type( 'section',
        array(
            'labels' => array(
                'name' => esc_html__( 'Sections', "stock-toolkit" ),
                'singular_name' => esc_html__( 'Section', "stock-toolkit" ),
            ),
            'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
            'public' => false,
            'show_ui' => true,
            'menu_icon' => 'dashicons-pressthis',
        )
    );
}



